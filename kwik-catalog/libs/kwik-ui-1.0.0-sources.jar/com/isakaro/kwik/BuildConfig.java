/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.isakaro.kwik;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.isakaro.kwik";
  public static final String BUILD_TYPE = "release";
}
