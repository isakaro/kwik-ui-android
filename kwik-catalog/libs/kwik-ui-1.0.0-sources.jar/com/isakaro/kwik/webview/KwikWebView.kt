package com.isakaro.kwik.webview

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import com.isakaro.kwik.loading.KwikCircularLoading

data class KwikWebViewSettings(
    val userAgent: String = "Kwik-Android-WebView",
    val cookies: List<KwikCookie> = emptyList(),
    val debug: Boolean = false,
    val javaScriptEnabled: Boolean = true,
    val domStorageEnabled: Boolean = true,
    val allowFileAccess: Boolean = true,
    val allowContentAccess: Boolean = true,
    val allowFileAccessFromFileURLs: Boolean = false,
    val allowUniversalAccessFromFileURLs: Boolean = false,
    val javaScriptCanOpenWindowsAutomatically: Boolean = true,
    val supportMultipleWindows: Boolean = true
)

@SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
@Composable
fun KwikWebView(
    modifier: Modifier = Modifier,
    url: String,
    javaScriptBridge: Any? = null,
    javaScriptBridgeName: String = "KwikBridge",
    hideProgressAfterLoading: Boolean = true,
    pageLoaded: () -> Unit = {},
    failedToOpenLink: () -> Unit = {},
    webViewSettings: KwikWebViewSettings.() -> Unit = {}
) {
    var valueCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val pageLoadingProgress = remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        valueCallback?.onReceiveValue(uris.toTypedArray())
        valueCallback = null
    }
    var progressVisible by remember { mutableStateOf(true) }
    var loaded by remember { mutableStateOf(false) }
    val _webViewSettings = KwikWebViewSettings().apply(webViewSettings)

    Box {
        Column(modifier = modifier) {
            if (progressVisible) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    progress = {
                        pageLoadingProgress.intValue / 100f
                    }
                )
            }

            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )

                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                if (request?.url.toString().startsWith("https://") || request?.url.toString().startsWith("http://")) {
                                    return false
                                }
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, request?.url.toString().toUri())
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    failedToOpenLink()
                                }
                                return true
                            }
                        }

                        settings.javaScriptEnabled = _webViewSettings.javaScriptEnabled
                        settings.domStorageEnabled = _webViewSettings.domStorageEnabled
                        settings.allowFileAccess = _webViewSettings.allowFileAccess
                        settings.allowContentAccess = _webViewSettings.allowContentAccess
                        settings.allowFileAccessFromFileURLs = _webViewSettings.allowFileAccessFromFileURLs
                        settings.allowUniversalAccessFromFileURLs = _webViewSettings.allowFileAccessFromFileURLs
                        settings.javaScriptCanOpenWindowsAutomatically = _webViewSettings.javaScriptCanOpenWindowsAutomatically
                        settings.setSupportMultipleWindows(_webViewSettings.supportMultipleWindows)

                        WebView.setWebContentsDebuggingEnabled(_webViewSettings.debug)

                        javaScriptBridge?.let {
                            addJavascriptInterface(it, javaScriptBridgeName)
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                pageLoadingProgress.intValue = newProgress
                                if (newProgress == 100) {
                                    pageLoaded()
                                    if(hideProgressAfterLoading){
                                        progressVisible = false
                                    }
                                    loaded = true
                                }
                            }

                            override fun onShowFileChooser(
                                webView: WebView,
                                filePathCallback: ValueCallback<Array<Uri>>,
                                fileChooserParams: FileChooserParams
                            ): Boolean {
                                try {
                                    valueCallback?.onReceiveValue(null)
                                    valueCallback = filePathCallback

                                    /**
                                     * image / * uses gallery picker which sometimes causes ERR_UPLOAD_FILE_CHANGED issue on some devices
                                     * we'll use * / * for now
                                     */
                                    val mimeType = if (fileChooserParams.acceptTypes.all { it.lowercase() in listOf(".jpg", ".jpeg", ".png") }) {
                                        "image/*"
                                    } else {
                                        "*/*"
                                    }

                                    launcher.launch("*/*")
                                } catch (e: Exception) {
                                    return false
                                }
                                return true
                            }

                            override fun onCreateWindow(
                                view: WebView?,
                                isDialog: Boolean,
                                isUserGesture: Boolean,
                                resultMsg: android.os.Message?
                            ): Boolean {
                                val newWebView = WebView(view?.context!!).apply {
                                    settings.javaScriptEnabled = _webViewSettings.javaScriptEnabled
                                    settings.domStorageEnabled = _webViewSettings.domStorageEnabled
                                    settings.allowFileAccess = _webViewSettings.allowFileAccess
                                    settings.allowContentAccess = _webViewSettings.allowContentAccess
                                    settings.allowFileAccessFromFileURLs = _webViewSettings.allowFileAccessFromFileURLs
                                    settings.allowUniversalAccessFromFileURLs = _webViewSettings.allowFileAccessFromFileURLs
                                    settings.javaScriptCanOpenWindowsAutomatically = _webViewSettings.javaScriptCanOpenWindowsAutomatically
                                    settings.setSupportMultipleWindows(_webViewSettings.supportMultipleWindows)

                                    webViewClient = object : WebViewClient() {
                                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                            if (request?.url.toString().startsWith("https://") || request?.url.toString().startsWith("http://")) {
                                                return false
                                            }
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, request?.url.toString().toUri())
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                failedToOpenLink()
                                            }
                                            return true
                                        }
                                    }

                                    webChromeClient = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                        this@apply.webChromeClient
                                    } else {
                                        object : WebChromeClient() {

                                        }
                                    }
                                }

                                val transport = resultMsg?.obj as? WebView.WebViewTransport
                                transport?.webView = newWebView
                                resultMsg?.sendToTarget()

                                return true
                            }
                        }
                        setCookie(_webViewSettings.cookies)
                        loadUrl(url)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
        if(!loaded){
            KwikCircularLoading(
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

fun WebView.setCookie(cookies: List<KwikCookie>){
    val cookieManager = CookieManager.getInstance()
    cookieManager.acceptCookie()
    cookies.forEach { cookie ->
        cookieManager.setCookie(cookie.domain, "${cookie.name}=${cookie.value}; path=${cookie.path}; expires=${cookie.expires}; name=${cookie.name}")
    }
    cookieManager.flush()
    cookieManager.setAcceptThirdPartyCookies(this, true)
}

data class KwikCookie(
    val name: String,
    val value: String,
    val domain: String,
    val path: String = "/",
    val expires: String = (30 * 24 * 60 * 60).toString() // 30 days
)

@Preview
@Composable
private fun KwikWebViewPreview() {
    KwikWebView(url = "https://www.google.com")
}
